<?php

/* @var $this yii\web\View */

use yii\helpers\Html;


$this->params['breadcrumbs'][] = ['label' => 'Regresar', 'url' => ['adulto/create']];

?>
<div class="site-about">
    <center><h1> Inscrito Correctamente</h1></center>   
</div>
